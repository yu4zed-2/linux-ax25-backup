void init_crc(void);
unsigned int calc_crc(unsigned char*, int, unsigned);
