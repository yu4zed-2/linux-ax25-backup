#ifndef AXSPAWN_H
#define AXSPAWN_H

#define EXITDELAY	10
int write_ax25(char *s, int len, int kick);
int Strcasecmp(const char *s1, const char *s2);

#endif
